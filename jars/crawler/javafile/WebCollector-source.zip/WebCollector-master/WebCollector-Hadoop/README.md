#WebCollector-Hadoop

WebCollector-Hadoop是WebCollector的分布式版本，目前为beta版本
