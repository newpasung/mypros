// CMT idiom
 Session sess = factory.getCurrentSession();
 // do some work
 ...
