SELECT id ,
       number ,
       type ,
       person_id
FROM   phone