SELECT *
FROM phone ph
JOIN call c ON c.phone_id = ph.id