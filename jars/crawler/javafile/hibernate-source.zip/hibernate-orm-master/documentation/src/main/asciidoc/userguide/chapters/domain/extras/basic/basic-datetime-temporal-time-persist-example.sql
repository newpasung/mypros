INSERT INTO DateEvent ( timestamp, id )
VALUES ( '16:51:58', 1 )